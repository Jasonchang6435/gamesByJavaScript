class GuaLabel {
    constructor(game,text) {
        this.game = game
        this.text = text

    }

    static new(game,text) {
        return new this(game,text)
    }

    draw() {
        this.game.context.fillText(this.text, 100, 190)
    }

    update() {

    }
}

class GuaParticle extends GuaImage {
    constructor(game) {
        super(game,'fire')
        // this.speed = 10
        this.setup()
        // this.setupInputs()
    }

    init(x,y,vx,vy) {
        this.x = x
        this.y = y
        this.vx = vx
        this.vy = vy
    }
    setup() {
        this.life = 30
        // this.speed = 10
    }

    update() {
        this.life--
        this.x += this.vx
        this.y += this.vy
        var factor = config.factor
        this.vx += factor * this.vx
        this.vy += factor * this.vy
    }
}

class GuaParticleSystem {
    constructor(game,text) {
        this.game = game
        this.text = text
        this.setup()
    }

    static new(game,text) {
        return new this(game,text)
    }

    setup() {
        this.duration = 60
        this.x = 100
        this.y = 150
        this.numberOfParticles = 20
        this.particles = []
    }

    update() {
        if (this.duration > 0) {
            this.duration--
        } else {
            this.duration = 0
            // return
        }
        // 添加小火花
        if (this.particles.length < this.numberOfParticles) {
            var p = GuaParticle.new(this.game)
            // 设置初始化坐标
            var speed = 2
            var vx = randomBetween(-speed,speed)
            var vy = randomBetween(-speed,speed)
            p.init(this.x,this.y,vx,vy)
            this.particles.push(p)
        }
        // 更新所有的小火花
        for(var p of this.particles) {
            p.update()
        }
        // 删除死掉的小火花
        this.particles = this.particles.filter(p => p.life > 0)
    }

    draw() {
        for(var p of this.particles) {
            p.draw()
        }
    }
}


class SceneTitle extends GuaScene {
    constructor(game) {
        super(game)
        var l = GuaLabel.new(this.game,'hello')
        this.addElement(l)
        // game.registerAction('k', function(){
        //     var s = Scene(game)
        //     game.replaceScene(s)
        // })
        // game.registerAction('e', function(){
        //     var e = SceneEditor.new(game)
        //     game.replaceScene(e)
        // })
        var ps = GuaParticleSystem.new(this.game)
        this.addElement(ps)
    }
    draw() {
        super.draw()
        // draw labels
        // this.game.context.fillText('按 k 开始游戏', 100, 190)
        // this.game.context.fillText('按 e 编辑关卡', 100, 150)
    }
}
