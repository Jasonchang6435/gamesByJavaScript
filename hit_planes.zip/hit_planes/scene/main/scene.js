const config = {
    player_speed: 10,
    cloud_speed: 1,
    enemy_speed: 5,
    bullet_speed: 5,
    fire_coolDown: 5,
    factor: 0.01,
}

class Bullet extends GuaImage {
    constructor(game) {
        super(game,'bullet')
        // this.speed = 10
        this.setup()
        // this.setupInputs()
    }

    setup() {
        this.speed = config.bullet_speed
        // this.speed = 10
    }

    update() {

        this.y -= this.speed
    }
}



class Player extends GuaImage {
    constructor(game) {
        super(game,'player')
        this.setup()
        // this.setupInputs()
    }

    setup() {
        this.speed = 10
        this.coolDown = 0
    }

    update() {
        this.speed = config.player_speed
        if (this.coolDown > 0) {
            this.coolDown -= 1
        }
    }

    fire() {
        if (this.coolDown === 0) {
            this.coolDown = config.fire_coolDown
            var x = this.x + this.w / 2
            var y = this.y
            var b = Bullet.new(this.game)
            b.x = x
            b.y = y
            this.scene.addElement(b)
        }
    }

    moveLeft() {
        this.x -= this.speed
        if (this.x < 0) {
            this.x = 0
        }
    }
    moveRight() {
        // log('debug',this,g.canvas.width,g.canvas.height)
        var g = this.game
        this.x += this.speed
        if (this.x + this.w > g.canvas.width) {
            this.x = g.canvas.width - this.w
        }
    }
    moveUp() {
        this.y -= this.speed
        if (this.y < 0) {
            this.y = 0
        }
    }
    moveDown() {
        // log('debug',this,g)
        var g = this.game
        this.y += this.speed
        if (this.y + this.h > g.canvas.height) {
            this.y = g.canvas.height - this.h
        }
    }
}

class Cloud extends GuaImage {
    constructor(game) {
        // var type = randomBetween(1,2)
        // var name = 'enemy' + type
        super(game,'cloud')
        this.setup()
        // this.setupInputs()
    }

    setup() {
        this.speed = config.cloud_speed
        this.x = randomBetween(0,150)
        this.y = -randomBetween(0,200)
    }

    update() {
        this.y += this.speed
        if (this.y > 600) {
            this.setup()
        }
    }

}


class Enemy extends GuaImage {
    constructor(game) {
        var type = randomBetween(1,5)
        var name = 'enemy' + type
        super(game,name)
        this.setup()
        // this.setupInputs()
    }

    setup() {
        this.speed = randomBetween(2,5)
        this.x = randomBetween(0,350)
        this.y = -randomBetween(0,200)
    }

    update() {
        this.y += this.speed
        if (this.y + this.h > this.game.canvas.height) {
            this.setup()
        }
    }

    // moveLeft() {
    //     this.x -= this.speed
    // }
    // moveRight(g) {
    //     log('debug',this,g.canvas.width,g.canvas.height)
    //     this.x += this.speed
    // }
    // moveUp() {
    //     this.y -= this.speed
    // }
    // moveDown(g) {
    //     log('debug',this,g)
    //     this.y += this.speed
    // }
}




class Scene extends GuaScene {
    constructor(game) {
        super(game)
        this.setup()
        this.setupInputs()
    }

    setup() {
        var game = this.game
        var s = this
        this.numOfEnemies = 5
        this.bg = GuaImage.new(game,'sky')
        // this.cloud = GuaImage.new(game,'cloud')
        // this.player = GuaImage.new(game,'player')
        // this.elements = []
        this.player = Player.new(game)
        this.cloud = Cloud.new(game)
        this.player.x = 200
        this.player.y = 200
        // this.elements.push(this.bg)
        this.addElement(this.bg)
        this.addElement(this.cloud)
        this.addElement(this.player)
        this.addEnemies()
        // add particles
        var p = GuaParticleSystem.new(this.game)
        this.addElement(p)
    }

    addEnemies() {
        var es = []
        for (var i = 0; i < this.numOfEnemies; i++) {
            var e = Enemy.new(this.game)
            es.push(e)
            this.addElement(e)
        }
        this.enemies = es
    }

    setupInputs() {
        var g = this.game
        var s = this
        g.registerAction('a', function(){
            s.player.moveLeft()
        })

        g.registerAction('d', function(){
            s.player.moveRight()
        })

        g.registerAction('w', function(){
            s.player.moveUp()
        })

        g.registerAction('s', function(){
            s.player.moveDown()
        })

        g.registerAction('j', function(){
            s.player.fire()
        })
    }

    update() {
        super.update()
        this.cloud.y += 1
    }
    // draw() {
        // draw labels
        // this.game.drawImage(this.bg)
        // this.game.drawImage(this.player)
    // }
}
