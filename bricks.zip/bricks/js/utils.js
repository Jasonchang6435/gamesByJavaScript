var log = console.log.bind(console)

var e = sel => document.querySelector(sel)
